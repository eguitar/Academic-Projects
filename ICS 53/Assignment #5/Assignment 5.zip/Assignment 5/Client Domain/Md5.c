// The 'Md5.c' code goes here.

#include<stdio.h>
#include<unistd.h>

int md5_print()
{
	int i;
	
	printf("I am MD5 API for the client.\n");
	
	return 0;
}
