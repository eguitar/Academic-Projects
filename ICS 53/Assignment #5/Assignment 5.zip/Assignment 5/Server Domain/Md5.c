
#include<stdio.h>
#include<unistd.h>

int md5_print()
{
	int i;
	
	printf("I am MD5 API for the server.\n");
	
	return 0;
}
